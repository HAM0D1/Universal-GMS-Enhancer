set -o standalone

(
until [ $(resetprop sys.boot_completed) -eq 1 ] &&
[ -d /sdcard ]; do
sleep 100
done

GMS="com.google.android.gms"
GC1="auth.managed.admin.DeviceAdminReceiver"
GC2="mdm.receivers.MdmDeviceAdminReceiver"
NLL="/dev/null"

for U in $(ls /data/user); do
for C in $GC1 $GC2 $GC3; do
pm disable --user $U "$GMS/$GMS.$C" &> $NLL
done
done

dumpsys deviceidle whitelist -com.google.android.gms &> $NLL

sleep 110

for i in $(ls /data/user/)
do
pm disable com.google.android.gms/com.google.android.gms.auth.managed.admin.DeviceAdminReceiver
pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
pm disable com.google.android.gms/.chimera.GmsIntentOperationService
cmd appops set com.google.android.gms BOOT_COMPLETED ignore
cmd appops set com.google.android.ims BOOT_COMPLETED ignore
cmd appops set com.google.android.gms BOOT_COMPLETED ignore
cmd appops set com.google.android.ims BOOT_COMPLETED ignore
cmd appops set com.google.android.gms.location.history BOOT_COMPLETED ignore
cmd appops set com.google.android.gm BOOT_COMPLETED ignore
cmd appops set com.google.android.marvin.talkback BOOT_COMPLETED ignore
cmd appops set com.google.android.apps.googleassistant BOOT_COMPLETED ignore
cmd appops set com.google.android.apps.carrier.log BOOT_COMPLETED ignore
cmd appops set com.android.providers.partnerbookmarks BOOT_COMPLETED ignore
cmd appops set com.google.android.apps.wellbeing BOOT_COMPLETED ignore
cmd appops set com.google.android.as BOOT_COMPLETED ignore
cmd appops set com.android.connectivity.metrics BOOT_COMPLETED ignore
cmd appops set com.android.bips BOOT_COMPLETED ignore
cmd appops set com.google.android.printservice.recommendation BOOT_COMPLETED ignore
cmd appops set com.android.hotwordenrollment.xgoogle BOOT_COMPLETED ignore
cmd appops set com.google.android.printservice.recommendation BOOT_COMPLETED ignore
cmd appops set com.android.hotwordenrollment.xgoogle BOOT_COMPLETED ignore
cmd appops set com.google.android.gms AUTO_START ignore
cmd appops set com.google.android.ims AUTO_START ignore
cmd appops set com.xiaomi.finddevice AUTO_START ignore
cmd appops set com.miui.analytics AUTO_START ignore
cmd appops set com.google.android.gms.location.history AUTO_START ignore
cmd appops set com.google.android.gm AUTO_START ignore
cmd appops set com.google.android.marvin.talkback AUTO_START ignore
cmd appops set com.google.android.apps.googleassistant AUTO_START ignore
cmd appops set com.google.android.apps.carrier.log AUTO_START ignore
cmd appops set com.android.providers.partnerbookmarks AUTO_START ignore
cmd appops set com.google.android.apps.wellbeing AUTO_START ignore
cmd appops set com.google.android.as AUTO_START ignore
cmd appops set com.android.connectivity.metrics AUTO_START ignore
cmd appops set com.android.bips AUTO_START ignore
cmd appops set com.google.android.printservice.recommendation AUTO_START ignore
cmd appops set com.android.hotwordenrollment.okgoogle AUTO_START ignore
cmd appops set com.android.hotwordenrollment.xgoogle AUTO_START ignore

done
#

(

    
    until [ "$(resetprop sys.boot_completed)" = "1" -a -d "/data" ]; do
        sleep 1
    done

    
    STATE_GMSF() {
        local PM="$(which pm)"
        local GMSF="com.google.android.gms/com.google.android.gms.fonts"

        for s in $(ls /data/user); do
            $PM $@ --user $s "$GMSF.update.UpdateSchedulerService"
            $PM $@ --user $s "$GMSF.provider.FontsProvider"
        done
    } &> /dev/null

    
    DEL_GMSF() {
        local GMSFD=com.google.android.gms/files/fonts

        for d in /data/fonts \
            /data/data/$GMSFD \
            /data/user/*/$GMSFD; do
            [ -d $d ] && rm -rf $d
        done
    }

    
    STATE_GMSF disable; DEL_GMSF
)

sleep 55

a="su -c"
b="pm disable com.google.android.gms/com.google.android.gms"
c="pm disable com.google.android.gms/com.google.android.location"
d="service"
e="ads.identifier"
f="analytics"
g="fitness"
h="cast"
i="chimera"
j="wearable"
k="media"
l="nearby"
m="games"
n="security"
o="snet"
p="stats"
q="tapandpay"
r="update"
s="common"
t="droidguard"
u="pay"
v="thunderbird"

$a "$b.$e.$d.AdvertisingIdService"
$a "$b.$e.$d.AdvertisingIdNotificationService"
$a "$b.nearby.mediums.nearfieldcommunication.NfcAdvertisingService"
$a "$b.$f.$d.AnalyticsService"
$a "$b.$f.AnalyticsService"
$a "$b.$f.AnalyticsTaskService"
$a "$b.$f.internal.PlayLogReportingService"
$a "$b.tron.CollectionService"
$a "$b.backup.stats.BackupStatsService"
$a "$b.$p.$d.DropBoxEntryAddedService"
$a "$b.$p.eastworld.EastworldService"
$a "$b.$s.$p.GmsCoreStatsService"
$a "$b.$p.PlatformStatsCollectorService"
$a "$b.$s.$p.StatsUploadService"
$a "$b.checkin.CheckinApiService"
$a "$b.checkin.CheckinService"
$a "$b.$s.config.PhenotypeCheckinService"
$a "$c.internal.server.HardwareArProviderService"
$a "$b.presencemanager.$d.PresenceManagerPresenceReportService"
$a "$c.reporting.$d.ReportingAndroidService"
$a "$b.locationsharingreporter.$d.reporting.periodic.PeriodicReporterMonitoringService"
$a "$b.$f.internal.PlayLogReportingService"
$a "$b.feedback.LegacyBugReportService"
$a "$b.$s.$p.net.NetworkReportService"
$a "$b.feedback.OfflineReportSendTaskService"
$a "$b.googlehelp.metrics.ReportBatchedMetricsGcmTaskService"
$a "$c.reporting.$d.ReportingSyncService"
$a "$b.usagereporting.$d.UsageReportingIntentService"
$a "$b.feedback.FeedbackAsyncService"
$a "$b.$h.$d.CastPersistentService_Persistent"
$a "$b.$i.CastPersistentBoundBrokerService"
$a "$b.$h.$k.CastMediaRoute2ProviderService"
$a "$b.$h.$k.CastMediaRoute2ProviderService_Isolated"
$a "$b.$h.$k.CastMediaRoute2ProviderService_Persistent"
$a "$b.$h.$k.CastMediaRouteProviderService"
$a "$b.$h.$k.CastMediaRouteProviderService_Isolated"
$a "$b.$h.$k.CastMediaRouteProviderService_Persistent"
$a "$b.$h.$k.CastRemoteDisplayProviderService"
$a "$b.$h.$k.CastRemoteDisplayProviderService_Isolated"
$a "$b.$h.$k.CastRemoteDisplayProviderService_Persistent"
$a "$b.$h.$d.CastSocketMultiplexerLifeCycleService"
$a "$b.$h.$d.CastSocketMultiplexerLifeCycleService_Isolated"
$a "$b.$h.$d.CastSocketMultiplexerLifeCycleService_Persistent"
$a "$b.clearcut.debug.ClearcutDebugDumpService"
$a "$b.$l.messages.debug.DebugPokeService"
$a "$b.$l.discovery.$d.DiscoveryService"
$a "pm disable com.google.android.gms/com.google.firebase.components.ComponentDiscoveryService"
$a "pm disable com.google.android.gms/com.google.mlkit.common.internal.MlKitComponentDiscoveryService"
$a "$b.geotimezone.GeoTimeZoneService"
$a "$b.location.geocode.GeocodeService"
$a "$b.$g.$d.ble.FitBleBroker"
$a "$b.$g.$d.config.FitConfigBroker"
$a "$b.$g.$d.goals.FitGoalsBroker"
$a "$b.$g.$d.history.FitHistoryBroker"
$a "$b.$g.$d.internal.FitInternalBroker"
$a "$b.$g.$d.proxy.FitProxyBroker"
$a "$b.$g.$d.recording.FitRecordingBroker"
$a "$b.$g.$d.sensors.FitSensorsBroker"
$a "$b.$g.$d.sessions.FitSessionsBroker"
$a "$b.$g.sync.FitnessSyncAdapterService"
$a "$b.$g.sensors.sample.CollectSensorService"
$a "$b.$g.cache.DataUpdateListenerCacheService"
$a "$b.$g.sync.SyncGcmTaskService"
$a "$b.$q.globalactions.QuickAccessWalletService"
$a "$b.$q.globalactions.WalletQuickAccessWalletService"
$a "$b.wallet.$d.WalletGcmTaskService"
$a "$b.$u.gcmtask.PayGcmTaskService"
$a "$b.$u.hce.$d.PayHceService"
$a "$b.$u.notifications.PayNotificationService"
$a "$b.wallet.$d.PaymentService"
$a "$b.$q.gcmtask.TapAndPayGcmTaskService"
$a "$b.gp.gameservice.GameService"
$a "$b.gp.gameservice.GameSessionService"
$a "$b.$m.$i.GamesSignInIntentServiceProxy"
$a "$b.$m.$i.GamesSyncServiceNotificationProxy"
$a "$b.$m.$i.GamesUploadServiceProxy"
$a "$b.instantapps.$d.InstantAppsService"
$a "$b.$i.GmsApiServiceNoInstantApps"
$a "$b.$i.PersistentApiServiceNoInstantApps"
$a "$b.$i.UiApiServiceNoInstantApps"
$a "$c.fused.FusedLocationService"
$a "$b.location.persistent.LocationPersistentService"
$a "$c.internal.server.GoogleLocationService"
$a "$c.network.NetworkLocationService"
$a "$c.util.LocationAccuracyInjectorService"
$a "$c.reporting.$d.LocationHistoryInjectorService"
$a "$b.locationsharing.$d.LocationSharingService"
$a "$b.locationsharing.$d.LocationSharingSettingInjectorService"
$a "$b.semanticlocation.$d.SemanticLocationService"
$a "$c.$j.WearableLocationService"
$a "$b.$g.sensors.sample.CollectSensorService"
$a "$b.$g.cache.DataUpdateListenerCacheService"
$a "$b.$g.sync.SyncGcmTaskService"
$a "$b.$f.internal.PlayLogReportingService"
$a "$b.romanesco.ContactsLoggerUploadService"
$a "$b.magictether.logging.DailyMetricsLoggerService"
$a "$b.checkin.EventLogService"
$a "$b.backup.component.FullBackupJobLoggerService"
$a "$b.$l.bootstrap.$d.NearbyBootstrapService"
$a "$b.$l.connection.$d.NearbyConnectionsAndroidService"
$a "pm disable com.google.android.gms/com.google.location.$l.direct.$d.NearbyDirectService"
$a "$b.$l.messages.$d.NearbyMessagesService"
$a "$b.$t.DroidGuardService"
$a "$b.$t.DroidGuardService_DroidGuardIsolated"
$a "$b.$t.DroidGuardGcmTaskService"
$a "$b.$n.safebrowsing.SafeBrowsingUpdateTaskService"
$a "$b.$n.verifier.ApkUploadService"
$a "$b.$n.verifier.InternalApkUploadService"
$a "$b.$n.$o.SnetIdleTaskService"
$a "$b.$n.$o.SnetNormalTaskService"
$a "$b.$n.$o.SnetService"
$a "$b.$u.$n.storagekey.$d.StorageKeyCacheService"
$a "$b.$q.$n.StorageKeyCacheService"
$a "$b.$v.EmergencyPersistentService"
$a "$b.$v.EmergencyLocationService"
$a "$b.personalsafety.$d.PersonalSafetyService"
$a "$b.kids.$i.KidsServiceProxy"
$a "$b.enpromo.PromoInternalPersistentService"
$a "$b.enpromo.PromoInternalService"
$a "$b.auth.trustagent.GoogleTrustAgent"
$a "$b.trustagent.api.bridge.TrustAgentBridgeService"
$a "$b.trustagent.api.state.TrustAgentStateService"
$a "$b.instantapps.routing.DomainFilterUpdateService"
$a "$b.auth.folsom.$d.FolsomPublicKeyUpdateService"
$a "$b.icing.proxy.IcingInternalCorporaUpdateService"
$a "$b.phenotype.$d.sync.PackageUpdateTaskService"
$a "$b.mobiledataplan.$d.PeriodicUpdaterService"
$a "$b.$r.SystemUpdateGcmTaskService"
$a "$b.$r.SystemUpdateService"
$a "$b.$r.UpdateFromSdCardService"
$a "$b.fonts.$r.UpdateSchedulerService"
$a "$b.dck.$d.DckWearableListenerService"
$a "$b.$l.fastpair.$d.WearableDataListenerService"
$a "$c.$j.WearableLocationService"
$a "$c.fused.$j.GmsWearableListenerService"
$a "$b.mdm.services.MdmPhoneWearableListenerService"
$a "$b.$q.wear.WearProxyService"
$a "$b.$j.$d.WearableControlService"
$a "$b.$j.$d.WearableService"
$a "$b.$g.$d.$j.WearableSyncAccountService"
$a "$b.$g.$d.$j.WearableSyncConfigService"
$a "$b.$g.$d.$j.WearableSyncConnectionService"
$a "$b.$g.$d.$j.WearableSyncMessageService"
$a "$b.$g.wearables.WearableSyncService"
$a "$b.backup.wear.BackupSettingsListenerService"

sleep 3

su -c "pm enable com.google.android.gms/com.google.android.gms.chimera.PersistentIntentOperationService_AuthAccountIsolated"
su -c "pm enable com.google.android.gms/com.google.android.gms.chimera.GmsIntentOperationService_AuthAccountIsolated com.google.android.gms/com.google.android.gms.chimera.GmsIntentOperationService_AuthAccountIsolate"
su -c "pm enable com.google.android.gms/com.google.android.gms.chimera.PersistentApiService_AuthAccountIsolated"

#
write() {
	[[ ! -f "$1" ]] && return 1
	chmod +w "$1" 2> /dev/null

	
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}
sync

sleep 20

su -c "pm disable com.google.android.apps.wellbeing/.powerstate.impl.PowerStateJobService"
su -c "pm disable com.google.android.apps.wellbeing/androidx.work.impl.background.systemjob.SystemJobService"

sleep 3

su -c pm disable com.google.android.apps.messaging/.shared.analytics.recurringmetrics..AnalyticsAlarmReceiver
su -c pm disable com.google.android.location.internal.UPLOAD_ANALYTICS
su -c pm disable com.facebook.orca/com.facebook.analytics.apptatelogger.AppStateIntentService
su -c pm disable com.facebook.orca/com.facebook.analytics2.Logger.LollipopUploadService
su -c pm disable com.google.android.gms/com.google.android.gms.nearby.bootstrap.service.NearbyBootstrapService
su -c pm disable com.google.android.gms/NearbyMessagesService
su -c pm disable com.google.android.gms/com.google.android.gms.nearby.connection.service.NearbyConnectionsAndroidService
su -c pm disable com.google.android.gms/com.google.location.nearby.direct.service.NearbyDirectService
su -c pm disable com.google.android.gms/com.google.android.gms.lockbox.LockboxService
su -c pm disable com.google.android.gms/com.google.android.gms.auth.trustagent.GoogleTrustAgent
su -c pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsTaskService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.cache.CacheBrokerService
su -c pm disable com.google.android.gms/com.android.billingclient.api.ProxyBillingActivity
su -c pm disable com.google.android.gms/com.google.android.gms.ads.measurement.GmpConversionTrackingBrokerService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.config.FlagsReceiver
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.service.MeasurementBrokerService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.adinfo.AdvertisinglnfoContentProvider
su -c pm disable com.google.android.gms/com.google.android.gms.ads.AdRequestBrokerService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.jams.NegotiationService
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.PackageMeasurementService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.social.GcmSchedulerWakeupService
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.PackageMeasurementTaskService
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.PackageMeasurementReceiver
su -c pm disable com.google.android.gms/com.google.android.gms.ads.identifier.service.AdvertisingldService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.GservicesValueBrokerService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.settings.AdsSettingsActivity
su -c pm disable com.google.android.gms/com.google.android.gms.ads.identifier.service.AdvertisingldNotificationService
su -c pm disable com.android.statementservice/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.messaging/com.google.android.apps.messaging.shared.analytics.recurringmetrics.AnalyticsAlarmReceiver
su -c pm disable com.google.android.apps.messaging/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.photos/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.restore/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.as/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.contacts/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.dialer/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.gm/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.google.android.gms/com.google.android.gms.analytics.internal.PlayLogReportingService
su -c pm disable com.google.android.gms/com.google.android.gms.analytics.service.AnalyticsService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.analytics.AnalyticsTaskService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.ar.core.services.AnalyticsService 
su -c pm disable com.google.android.apps.messaging.shared.analytics.recurringmetrics.AnalyticsAlarmReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.facebook.analytics2.logger.AlarmBasedUploadService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.facebook.analytics2.logger.LollipopUploadService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.facebook.analytics2.logger.GooglePlayUploadService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.facebook.analytics2.logger.HighPriUploadRetryReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.facebook.analytics.appstatelogger.AppStateBroadcastReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.facebook.analytics.appstatelogger.AppStateIntentService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.facebook.adspayments.analytics.ExperimentExposeService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.analytics.internal.GServicesChangedReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.analytics.AnalyticsService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.analytics.internal.PlayLogReportingService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.analytics.service.AnalyticsService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.analytics.service.PlayLogMonitorIntervalService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.analytics.service.RefreshEnabledStateService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.common.analytics.CoreAnalyticsIntentService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.common.analytics.CoreAnalyticsReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.gameanalytics.sdk.errorreporter.GameAnalyticsExceptionReportService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.samsung.android.hmt.vrsvc.receiver.AnalyticsLogReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.projection.gearhead/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.settings.intelligence/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.syncadapters.contacts/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.google.android.syncadapters.contacts/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.vanced.android.youtube/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.android.vending/com.google.android.gms.measurement.AppMeasurementJobService
su -c pm disable com.android.vending/com.google.android.gms.measurement.AppMeasurementReceiver
su -c pm disable com.android.vending/com.google.android.gms.measurement.AppMeasurementService
su -c pm disable com.google.android.apps.photos/com.google.android.gms.measurement.AppMeasurementJobService
su -c pm disable com.google.android.apps.photos/com.google.android.gms.measurement.AppMeasurementReceiver
su -c pm disable com.google.android.apps.photos/com.google.android.gms.measurement.AppMeasurementService
su -c pm disable com.google.android.calculator/com.google.android.gms.measurement.AppMeasurementJobService
su -c pm disable com.google.android.calculator/com.google.android.gms.measurement.AppMeasurementReceiver
su -c pm disable com.google.android.calculator/com.google.android.gms.measurement.AppMeasurementService
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.AppMeasurementJobService
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.AppMeasurementReceiver
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.AppMeasurementService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.measurement.AppMeasurementInstallReferrerReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.measurement.AppMeasurementJobService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.measurement.AppMeasurementReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.measurement.AppMeasurementContentProvider
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.measurement.AppMeasurementService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gearhead.telemetry.InstallReferrerReceiver
su -c pm disable com.google.android.projection.gearhead/com.google.android.gearhead.telemetry.InstallReferrerReceiver
su -c pm disable com.google.android.syncadapters.contacts/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.xiaomi.misettings/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.cameralite/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.gcs/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.helprtc/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.nbu.files/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.recorder/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.safetyhub/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.security.securityhub/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.wearables.maestro.companion/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.work.clouddpc/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.calendar/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.googlequicksearchbox/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.odad/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.tts/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.ar.core/com.google.ar.core.services.AnalyticsService
su -c pm disable com.google.ar.core/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.motorola.dolby.dolbyui/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.GoogleCameraEng/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.google.android.GoogleCameraEng/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.google.android.GoogleCameraEng/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.analytics.tracking.android.CampaignTrackingReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.analytics.tracking.android.CampaignTrackingService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.analytics.CampaignTrackingService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.analytics.CampaignTrackingReceiver
su -c pm disable com.google.android.projection.gearhead/com.google.android.gms.analytics.CampaignTrackingService
su -c pm disable com.google.android.apps.docs/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.apps.messaging.shared.analytics.recurringmetrics.AnalyticsAlarmReceiver
su -c pm disable com.google.android.ims/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.whatsapp/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.whatsapp/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.whatsapp/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.whatsapp/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.facebook.katana/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.facebook.katana/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.facebook.katana/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.facebook.katana/com.facebook.analytics2.logger.AlarmBasedUploadService
su -c pm disable com.facebook.katana/com.facebook.analytics2.logger.LollipopUploadService
su -c pm disable com.facebook.katana/com.facebook.analytics2.logger.GooglePlayUploadService
su -c pm disable com.facebook.katana/com.facebook.analytics2.logger.HighPriUploadRetryReceiver
su -c pm disable com.facebook.katana/com.facebook.analytics.appstatelogger.AppStateBroadcastReceiver
su -c pm disable com.facebook.katana/com.facebook.analytics.appstatelogger.AppStateIntentService
su -c pm disable com.facebook.katana/com.facebook.adspayments.analytics.ExperimentExposeService
su -c pm disable com.instagram.android/com.instagram.analytics.uploadscheduler.AnalyticsUploadAlarmReceiver
su -c pm disable com.instagram.android/com.instagram.common.analytics.phoneid.InstagramPhoneIdRequestReceiver
su -c pm disable com.instagram.android/com.instagram.common.analytics.phoneid.InstagramPhoneIdRequestReceiver
su -c pm disable com.instagram.android/com.instagram.analytics.uploadscheduler.AnalyticsUploadAlarmReceiver
su -c pm disable com.instagram.android/com.facebook.analytics2.logger.AlarmBasedUploadService
su -c pm disable com.instagram.android/com.facebook.analytics2.logger.LollipopUploadService
su -c pm disable com.instagram.android/com.facebook.analytics2.logger.GooglePlayUploadService
su -c pm disable com.instagram.android/com.facebook.analytics2.logger.HighPriUploadRetryReceiver
su -c pm disable com.instagram.android/com.facebook.analytics.appstatelogger.AppStateBroadcastReceiver
su -c pm disable com.instagram.android/com.facebook.analytics.appstatelogger.AppStateIntentService
su -c pm disable com.adobe.lrmobile/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.adobe.reader/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.adobe.scan.android/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.coolapk.market/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.digipom.easyvoicerecorder.pro/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.handmark.expressweather/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.instagram.android/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.mcdo.mcdonalds/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.mcdo.mcdonalds/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.mcdo.mcdonalds/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.mcdo.mcdonalds/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.mcdo.mcdonalds/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.mcdo.mcdonalds/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.microsoft.office.word/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.microsoft.teams/com.firebase.jobdispatcher.GooglePlayReceiver
su -c pm disable com.microsoft.teams/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.miui.gallery/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.miui.mediaeditor/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.yahoo.mobile.client.android.mail/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.yahoo.mobile.client.android.mail/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.yahoo.mobile.client.android.mail/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.yahoo.mobile.client.android.mail/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.yahoo.mobile.client.android.mail/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.yahoo.mobile.client.android.mail/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable ir.ilmili.telegraph/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable mx.com.miapp/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable org.zwanoo.android.speedtest/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable org.zwanoo.android.speedtest/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable org.zwanoo.android.speedtest/com.google.android.gms.analytics.AnalyticsService
su -c pm disable org.zwanoo.android.speedtest/com.google.android.gms.analytics.AnalyticsService
su -c pm disable org.zwanoo.android.speedtest/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable pl.solidexplorer2/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.magazines/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.google.android.apps.magazines/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.google.android.apps.magazines/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.google.android.apps.magazines/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.google.android.apps.magazines/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.alibaba.analytics.AnalyticsService
su -c pm disable com.facebook.analytics2.logger.service.LollipopUploadSafeService
su -c pm disable com.vanced.android.youtube/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.alibaba.aliexpresshd/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.amazon.mShop.android.shopping/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.cris87.miui/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.speedymovil.wire/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable qrcodereader.barcodescanner.scan.qrscanner/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable video.player.videoplayer/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.facebook.orca/com.facebook.messaging.internalprefs.MessengerAnalyticsActivity
su -c pm disable com.facebook.orca/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.facebook.orca/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.facebook.orca/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.facebook.katana/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.ubercab/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.ubercab/com.braintreepayments.api.internal.AnalyticsIntentService

sleep 3
for i in $(ls /data/user/)
do

pm disable com.google.android.gms/.ads.AdRequestBrokerService
pm disable com.google.android.gms/.ads.GservicesValueBrokerService
pm disable com.google.android.gms/.ads.adinfo.AdvertisingInfoContentProvider
pm disable com.google.android.gms/.ads.config.FlagsReceiver
pm disable com.google.android.gms/.ads.config.GServicesChangedReceiver
pm disable com.google.android.gms/.ads.identifier.service.AdvertisingIdNotificationService
pm disable com.google.android.gms/.ads.identifier.service.AdvertisingIdService
pm disable com.google.android.gms/.ads.jams.NegotiationService
pm disable com.google.android.gms/.ads.jams.SystemEventReceiver
pm disable com.google.android.gms/.ads.measurement.GmpConversionTrackingBrokerService
pm disable com.google.android.gms/.ads.pan.PanService
pm disable com.google.android.gms/.ads.settings.AdsSettingsActivity
pm disable com.google.android.gms/.ads.social.DoritosReceiver
pm disable com.google.android.gms/.ads.social.GcmSchedulerWakeupService
pm disable com.google.android.gms/.analytics.AnalyticsReceiver
pm disable com.google.android.gms/.analytics.AnalyticsService
pm disable com.google.android.gms/.analytics.internal.GServicesChangedReceiver
pm disable com.google.android.gms/.analytics.internal.PlayLogReportingService
pm disable com.google.android.gms/.analytics.service.AnalyticsService
pm disable com.google.android.gms/.analytics.service.PlayLogMonitorIntervalService
pm disable com.google.android.gms/.analytics.service.RefreshEnabledStateService
pm disable com.google.android.gms/.auth.be.proximity.authorization.userpresence.UserPresenceService
pm disable com.google.android.gms/.backup.BackupStatsService
pm disable com.google.android.gms/.car.BroadcastRedirectActivity
pm disable com.google.android.gms/.car.CarErrorDisplayActivity
pm disable com.google.android.gms/.car.CarHomeActivity
pm disable com.google.android.gms/.car.CarHomeActivity1
pm disable com.google.android.gms/.car.CarHomeActivity2
pm disable com.google.android.gms/.car.CarIntentService
pm disable com.google.android.gms/.car.CarService
pm disable com.google.android.gms/.car.CarServiceSettingsActivity
pm disable com.google.android.gms/.car.FirstActivity
pm disable com.google.android.gms/.car.InCallServiceImpl
pm disable com.google.android.gms/.car.SetupActivity
pm disable com.google.android.gms/.car.VoiceActionService
pm disable com.google.android.gms/.car.diagnostics.CrashReporterService
pm disable com.google.android.gms/.checkin.CheckinService$ActiveReceiver
pm disable com.google.android.gms/.checkin.CheckinService$ClockworkFallbackReceiver
pm disable com.google.android.gms/.checkin.CheckinService$ImposeReceiver
pm disable com.google.android.gms/.checkin.CheckinService$SecretCodeReceiver
pm disable com.google.android.gms/.checkin.CheckinService$TriggerReceiver
pm disable com.google.android.gms/.checkin.EventLogService$Receiver
pm disable com.google.android.gms/.chimera.GmsIntentOperationService
pm disable com.google.android.gms/.common.analytics.CoreAnalyticsIntentService
pm disable com.google.android.gms/.common.analytics.CoreAnalyticsReceiver
pm disable com.google.android.gms/.common.stats.net.contentprovider.NetworkUsageContentProvider
pm disable com.google.android.gms/.config.ConfigService
pm disable com.google.android.gms/.deviceconnection.service.DeviceConnectionAsyncService
pm disable com.google.android.gms/.deviceconnection.service.DeviceConnectionServiceBroker
pm disable com.google.android.gms/.feedback.AnnotateScreenshotActivity
pm disable com.google.android.gms/.feedback.FeedbackActivity
pm disable com.google.android.gms/.feedback.FeedbackAsyncService
pm disable com.google.android.gms/.feedback.FeedbackConnectivityReceiver
pm disable com.google.android.gms/.feedback.FeedbackService
pm disable com.google.android.gms/.feedback.IntentListenerFeedbackActivity
pm disable com.google.android.gms/.feedback.LegacyBugReportService
pm disable com.google.android.gms/.feedback.PreviewActivity
pm disable com.google.android.gms/.feedback.PreviewScreenshotActivity
pm disable com.google.android.gms/.feedback.SendService
pm disable com.google.android.gms/.feedback.ShowTextActivity
pm disable com.google.android.gms/.feedback.SuggestionsActivity
pm disable com.google.android.gms/.fitness.disconnect.FitCleanupService
pm disable com.google.android.gms/.fitness.disconnect.FitDisconnectReceiver
pm disable com.google.android.gms/.fitness.sensors.activity.ActivityRecognitionService
pm disable com.google.android.gms/.fitness.sensors.floorchange.FloorChangeRecognitionService
pm disable com.google.android.gms/.fitness.sensors.sample.CollectSensorReceiver
pm disable com.google.android.gms/.fitness.sensors.sample.CollectSensorService
pm disable com.google.android.gms/.fitness.service.DebugIntentService
pm disable com.google.android.gms/.fitness.service.FitnessInitReceiver
pm disable com.google.android.gms/.fitness.service.ble.FitBleBroker
pm disable com.google.android.gms/.fitness.service.config.FitConfigBroker
pm disable com.google.android.gms/.fitness.service.history.FitHistoryBroker
pm disable com.google.android.gms/.fitness.service.internal.FitInternalBroker
pm disable com.google.android.gms/.fitness.service.proxy.FitProxyBroker
pm disable com.google.android.gms/.fitness.service.recording.FitRecordingBroker
pm disable com.google.android.gms/.fitness.service.sensors.FitSensorsBroker
pm disable com.google.android.gms/.fitness.service.sessions.FitSessionsBroker
pm disable com.google.android.gms/.fitness.settings.FitnessSettingsActivity
pm disable com.google.android.gms/.fitness.store.maintenance.StoreMaintenanceService
pm disable com.google.android.gms/.fitness.sync.FitnessContentProvider
pm disable com.google.android.gms/.fitness.sync.FitnessSyncAdapterService
pm disable com.google.android.gms/.fitness.wearables.WearableSyncService
pm disable com.google.android.gms/.fitness.wearables.WearableSyncServiceReceiver
pm disable com.google.android.gms/.googlehelp.GcmBroadcastReceiver
pm disable com.google.android.gms/.googlehelp.helpactivities.ClickToCallActivity
pm disable com.google.android.gms/.googlehelp.helpactivities.EmailActivity
pm disable com.google.android.gms/.googlehelp.helpactivities.HelpActivity
pm disable com.google.android.gms/.googlehelp.helpactivities.OpenHangoutActivity
pm disable com.google.android.gms/.googlehelp.helpactivities.OpenHelpActivity
pm disable com.google.android.gms/.googlehelp.helpactivities.RealtimeSupportClassifierActivity
pm disable com.google.android.gms/.googlehelp.helpactivities.SystemAppTrampolineActivity
pm disable com.google.android.gms/.googlehelp.metrics.ConnectivityBroadcastReceiver
pm disable com.google.android.gms/.googlehelp.metrics.MetricsReportService
pm disable com.google.android.gms/.googlehelp.metrics.ReportBatchedMetricsService
pm disable com.google.android.gms/.googlehelp.service.ChatStatusUpdateService
pm disable com.google.android.gms/.googlehelp.service.ClearHelpHistoryIntentService
pm disable com.google.android.gms/.googlehelp.service.GoogleHelpService
pm disable com.google.android.gms/.googlehelp.service.VideoCallStatusUpdateService
pm disable com.google.android.gms/.googlehelp.webview.GoogleHelpWebViewActivity
pm disable com.google.android.gms/.kids.GcmReceiverService
pm disable com.google.android.gms/.kids.account.AccountRemovalConfirmActivity
pm disable com.google.android.gms/.kids.account.AccountSetupActivity
pm disable com.google.android.gms/.kids.account.ShowAppsActivity
pm disable com.google.android.gms/.kids.account.activities.RegisterProfileOwnerActivity
pm disable com.google.android.gms/.kids.account.receiver.ProfileOwnerReceiver
pm disable com.google.android.gms/.kids.chimera.AccountChangeReceiverProxy
pm disable com.google.android.gms/.kids.chimera.AccountSetupCompletedReceiverProxy
pm disable com.google.android.gms/.kids.chimera.AccountSetupServiceProxy
pm disable com.google.android.gms/.kids.chimera.DeviceTimeAndDateChangeReceiverProxy
pm disable com.google.android.gms/.kids.chimera.InternalEventReceiverLmpProxy
pm disable com.google.android.gms/.kids.chimera.InternalEventReceiverProxy
pm disable com.google.android.gms/.kids.chimera.KidsApiServiceProxy
pm disable com.google.android.gms/.kids.chimera.KidsDataProviderProxy
pm disable com.google.android.gms/.kids.chimera.KidsDataSyncServiceProxy
pm disable com.google.android.gms/.kids.chimera.KidsServiceProxy
pm disable com.google.android.gms/.kids.chimera.LongRunningServiceProxy
pm disable com.google.android.gms/.kids.chimera.PackageChangedReceiverProxy
pm disable com.google.android.gms/.kids.chimera.SlowOperationServiceProxy
pm disable com.google.android.gms/.kids.chimera.SystemEventReceiverProxy
pm disable com.google.android.gms/.kids.chimera.TimeoutsSystemAlertServiceProxy
pm disable com.google.android.gms/.kids.common.sync.ManualSyncReceiver
pm disable com.google.android.gms/.kids.creation.activities.FamilyCreationActivity
pm disable com.google.android.gms/.kids.device.RingService
pm disable com.google.android.gms/.measurement.PackageMeasurementTaskService
pm disable com.google.android.gms/.measurement.service.MeasurementBrokerService
pm disable com.google.android.gms/.nearby.bootstrap.service.NearbyBootstrapService
pm disable com.google.android.gms/.nearby.connection.service.NearbyConnectionsAndroidService
pm disable com.google.android.gms/.nearby.connection.service.NearbyConnectionsAsyncService
pm disable com.google.android.gms/.nearby.messages.NearbyMessagesBroadcastReceiver
pm disable com.google.android.gms/.nearby.messages.service.NearbyMessagesService
pm disable com.google.android.gms/.nearby.messages.settings.NearbyMessagesAppOptInActivity
pm disable com.google.android.gms/.nearby.settings.NearbyAccessActivity
pm disable com.google.android.gms/.nearby.settings.NearbyAppUninstallReceiver
pm disable com.google.android.gms/.nearby.settings.NearbySettingsActivity
pm disable com.google.android.gms/.nearby.sharing.service.NearbySharingService
pm disable com.google.android.gms/.perfprofile.uploader.PerfProfileCollectorService
pm disable com.google.android.gms/.perfprofile.uploader.RequestPerfProfileCollectionService
pm disable com.google.android.gms/.phenotype.receiver.PhenotypeBroadcastReceiver
pm disable com.google.android.gms/.phenotype.service.PhenotypeCommitService
pm disable com.google.android.gms/.phenotype.service.PhenotypeIntentService
pm disable com.google.android.gms/.phenotype.service.sync.PhenotypeConfigurator
pm disable com.google.android.gms/.phenotype.service.util.PhenotypeDebugService
pm disable com.google.android.gms/.photos.InitializePhotosIntentReceiver
pm disable com.google.android.gms/.photos.autobackup.AutoBackupWorkService
pm disable com.google.android.gms/.photos.autobackup.service.AutoBackupService
pm disable com.google.android.gms/.photos.autobackup.ui.AutoBackupSettingsActivity
pm disable com.google.android.gms/.photos.autobackup.ui.AutoBackupSettingsRedirectActivity
pm disable com.google.android.gms/.photos.autobackup.ui.LocalFoldersBackupSettings
pm disable com.google.android.gms/.photos.autobackup.ui.promo.AutoBackupPromoActivity
pm disable com.google.android.gms/.plus.activity.AccountSignUpActivity
pm disable com.google.android.gms/.plus.apps.ListAppsActivity
pm disable com.google.android.gms/.plus.apps.ManageAppActivity
pm disable com.google.android.gms/.plus.apps.ManageDeviceActivity
pm disable com.google.android.gms/.plus.apps.ManageMomentActivity
pm disable com.google.android.gms/.plus.audience.AclSelectionActivity
pm disable com.google.android.gms/.plus.audience.AudienceSearchActivity
pm disable com.google.android.gms/.plus.audience.CircleCreationActivity
pm disable com.google.android.gms/.plus.audience.CircleSelectionActivity
pm disable com.google.android.gms/.plus.audience.FaclSelectionActivity
pm disable com.google.android.gms/.plus.audience.UpdateActionOnlyActivity
pm disable com.google.android.gms/.plus.audience.UpdateCirclesActivity
pm disable com.google.android.gms/.plus.circles.AddToCircleConsentActivity
pm disable com.google.android.gms/.plus.oob.PlusActivity
pm disable com.google.android.gms/.plus.oob.UpgradeAccountActivity
pm disable com.google.android.gms/.plus.oob.UpgradeAccountInfoActivity
pm disable com.google.android.gms/.plus.plusone.PlusOneActivity
pm disable com.google.android.gms/.plus.provider.PlusProvider
pm disable com.google.android.gms/.plus.service.DefaultIntentService
pm disable com.google.android.gms/.plus.service.ImageIntentService
pm disable com.google.android.gms/.plus.service.OfflineActionSyncAdapterService
pm disable com.google.android.gms/.plus.service.PlusService
pm disable com.google.android.gms/.plus.sharebox.AddToCircleActivity
pm disable com.google.android.gms/.plus.sharebox.ReplyBoxActivity
pm disable com.google.android.gms/.plus.sharebox.ShareBoxActivity
pm disable com.google.android.gms/.pseudonymous.service.PseudonymousIdIntentService
pm disable com.google.android.gms/.pseudonymous.service.PseudonymousIdService
pm disable com.google.android.gms/.update.SystemUpdateService$ActiveReceiver
pm disable com.google.android.gms/.update.SystemUpdateService$OtaPolicyReceiver
pm disable com.google.android.gms/.update.SystemUpdateService$Receiver
pm disable com.google.android.gms/.update.SystemUpdateService$SecretCodeReceiver
pm disable com.google.android.gms/.usagereporting.service.UsageReportingService
pm disable com.google.android.gms/.usagereporting.settings.UsageReportingActivity
pm disable com.google.android.gms/.wallet.service.analytics.AnalyticsIntentService
pm disable com.google.android.gms/.wifi.gatherer2.receiver.GoogleAccountChangeReceiver
pm disable com.google.android.gms/.wifi.gatherer2.receiver.WifiStateChangeReceiver
pm disable com.google.android.gms/.wifi.gatherer2.service.GcmReceiverService
pm disable com.google.android.gms/.wifi.gatherer2.service.KeyManagerServce
pm disable com.google.android.gms/.wifi.gatherer2.service.WifiUpdateRetryTaskService
pm disable com.google.android.gms/com.google.android.contextmanager.service.ContextManagerService
pm disable com.google.android.gms/com.google.android.contextmanager.systemstate.SystemStateReceiver
pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
pm disable com.google.android.gms/com.google.android.libraries.social.mediamonitor.MediaMonitor
pm disable com.google.android.gms/com.google.android.libraries.social.mediamonitor.MediaMonitorIntentService
pm disable com.google.android.gsf/.checkin.CheckinService
pm disable com.google.android.gsf/.checkin.EventLogService
pm disable com.google.android.gsf/.checkin.EventLogService$Receiver
pm disable com.google.android.gsf/.update.SystemUpdateActivity
pm disable com.google.android.gsf/.update.SystemUpdatePanoActivity
pm disable com.google.android.gsf/.update.SystemUpdateService
pm disable com.google.android.gsf/.update.SystemUpdateService$Receiver
pm disable com.google.android.gsf/.update.SystemUpdateService$SecretCodeReceiver
pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$Receiver
pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$SecretCodeReceiver
pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$TriggerReceiver
pm enable com.google.android.gms/.checkin.CheckinService
pm enable com.google.android.gms/.checkin.EventLogService
pm enable com.google.android.gms/.common.stats.GmsCoreStatsService
pm enable com.google.android.gms/.common.stats.GmsCoreStatsServiceLauncher
pm enable com.google.android.gms/.phenotype.service.PhenotypeService
pm enable com.google.android.gms/.playlog.service.MonitorAlarmReceiver
pm enable com.google.android.gms/.playlog.service.MonitorService
pm enable com.google.android.gms/.playlog.service.PlayLogBrokerService
pm enable com.google.android.gms/.playlog.service.PlayLogIntentService
pm enable com.google.android.gms/.playlog.service.WallClockChangedReceiver
pm enable com.google.android.gms/.playlog.uploader.RequestUploadService
pm enable com.google.android.gms/.playlog.uploader.UploaderService
pm enable com.google.android.gms/.stats.PlatformStatsCollectorService
pm enable com.google.android.gms/.update.SystemUpdateService
done &> /dev/null

exit