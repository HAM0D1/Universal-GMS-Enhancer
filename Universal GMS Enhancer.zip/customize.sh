set -o standalone

set -x

[ $API -ge 23 ] ||
 abort "- Unsupported API version: $API"
ui_print "- Finding Files "
{
GMS0="\"com.google.android.gms"\"
STR1="allow-in-power-save package=$GMS0"
STR2="allow-in-data-usage-save package=$GMS0"
NULL="/dev/null"
}
ui_print "- Patching Files "
SYS_XML="$(
SXML="$(find /system_ext/* /system/* /product/* \
/vendor/* -type f -iname '*.xml' -print)"
for S in $SXML; do
if grep -qE "$STR1|$STR2" $ROOT$S 2> $NULL; then
echo "$S"
fi
done
)"

PATCH_SX() {
for SX in $SYS_XML; do
mkdir -p "$(dirname $MODPATH$SX)"
cp -af $ROOT$SX $MODPATH$SX
 ui_print "  Patching: $SX"
sed -i "/$STR1/d;/$STR2/d" $MODPATH/$SX
done

for P in product vendor; do
if [ -d $MODPATH/$P ]; then
 ui_print "- Moving files to module dir"
mkdir -p $MODPATH/system/$P
mv -f $MODPATH/$P $MODPATH/system/
fi
done
}

MOD_XML="$(
MXML="$(find /data/adb/* -type f -iname "*.xml" -print)"
for M in $MXML; do
if grep -qE "$STR1|$STR2" $M; then
echo "$M"
fi
done
)"

PATCH_MX() {
 ui_print "- almost Done "
for MX in $MOD_XML; do
MOD="$(echo "$MX" | awk -F'/' '{print $5}')"
 ui_print "  $MOD: $MX"
sed -i "/$STR1/d;/$STR2/d" $MX
done
}

PATCH_SX && PATCH_MX

ADDON() {
 ui_print "- installing add-on file"
mkdir -p $MODPATH/system/bin
mv -f $MODPATH/gmsc $MODPATH/system/bin/gmsc
}

FINALIZE() {
 ui_print "- installation Done "
 ui_print "  Cleaning old Files "
find $MODPATH/* -maxdepth 0 \
! -name 'module.prop' \
! -name 'post-fs-data.sh' \
! -name 'service.sh' \
! -name 'system' \
-exec rm -rf {} \;

 ui_print "  Settings permissions "
set_perm_recursive $MODPATH 0 0 0755 0755
set_perm $MODPATH/system/bin/gmsc 0 2000 0755
}

ADDON && FINALIZE

ui_print "add GMS Doze Tool to system"
if [ $BOOTMODE = true ]; then
ROOT=$(find `magisk --path` -type d -name "mirror" | head -n 1)
ui_print "- install as ROOT: $ROOT"
else
ROOT=""
fi

sdk="$(getprop ro.build.version.sdk)"
if [[ !"$sdk" -ge "23" ]]; then
ui_print "- Version Android NO supported: $sdk"
exit 1
fi

ui_print "- Patching Files "
gms=$(xml=$(find /system/ /product/ /vendor/ -iname "*.xml");for i in $xml; do if grep -q 'allow-in-power-save package="com.google.android.gms"' $ROOT$i 2>/dev/null; then echo "$i";fi; done)
ims=$(xml=$(find /system/ /product/ /vendor/ -iname "*.xml");for i in $xml; do if grep -q 'allow-in-power-save package="com.google.android.ims"' $ROOT$i 2>/dev/null; then echo "$i";fi; done)
pst=$(xml=$(find /system/ /product/ /vendor/ -iname "*.xml");for i in $xml; do if grep -q 'allow-in-power-save package="com.google.android.apps.safetyhub"' $ROOT$i 2>/dev/null; then echo "$i";fi; done)
trb=$(xml=$(find /system/ /product/ /vendor/ -iname "*.xml");for i in $xml; do if grep -q 'allow-in-power-save package="com.google.android.apps.turbo"' $ROOT$i 2>/dev/null; then echo "$i";fi; done)

for i in $gms $ims $pst $trb
do
mkdir -p `dirname $MODPATH$i`
cp -af $ROOT$i $MODPATH$i
sed -i '/allow-in-power-save package="com.google.android.gms"/d;/allow-in-data-usage-save package="com.google.android.gms"/d' $MODPATH$i
sed -i '/allow-in-power-save package="com.google.android.ims"/d;/allow-in-data-usage-save package="com.google.android.ims"/d' $MODPATH$i
sed -i '/allow-in-power-save package="com.google.android.apps.safetyhub"/d;/allow-in-data-usage-save package="com.google.android.apps.safetyhub"/d' $MODPATH$i
sed -i '/allow-in-power-save package="com.google.android.apps.turbo"/d;/allow-in-data-usage-save package="com.google.android.apps.turbo"/d' $MODPATH$i
done

for i in product vendor
do
if [ -d $MODPATH/$i ]; then
if [ ! -d $MODPATH/system/$i ]; then
sleep 1
ui_print "- Backup saved in /system... "
mkdir -p $MODPATH/system/$i
mv -f $MODPATH/$i $MODPATH/system/
else
rm -rf $MODPATH/$i
fi
fi
done

conflict1=$(xml=$(find /data/adb -iname "*.xml");for i in $xml; do if grep -q 'allow-unthrottled-location package="com.google.android.gms"' $i 2>/dev/null; then echo "$i";fi; done)
conflict2=$(xml=$(find /data/adb -iname "*.xml");for i in $xml; do if grep -q 'allow-ignore-location-settings package="com.google.android.gms"' $i 2>/dev/null; then echo "$i";fi; done)
for i in $conflict1 $conflict2
do
search=$(echo "$i" | sed -e 's/\// /g' | awk '{print $4}')
ui_print "- Module almost Done "
ui_print "   $search"
sed -i '/allow-unthrottled-location package="com.google.android.gms"/d;/allow-ignore-location-settings package="com.google.android.gms"/d' $i
done

ui_print "- Load add-on... "
mkdir -p $MODPATH/system/bin
mv -f $MODPATH/gmsc $MODPATH/system/bin/gmsc
chmod +x $MODPATH/system/bin/gmsc

ui_print "- install add-on "
cd /data/data
find . -type f -name '*gms*' -delete

ui_print " 1 sec "
sleep 1
ui_print "Done "
set -x
ui_print '- Installing'
ui_print ''

STATE_GMSF() {
    ui_print '- Checking Components'

    local GMS="com.google.android.gms"
    local GMFP="$GMS.fonts.provider.FontsProvider"
    local GMFS="$GMS.fonts.update.UpdateSchedulerService"

    local DCL="disabledComponents:"
    local ECL="enabledComponents:"
    local HSP="Hidden[[:space:]]system[[:space:]]packages:"

    local DATA="dumpsys package $GMS"

    CHECK() { $DATA | sed -n "/$1/,/$2/{/$3/p}" | xargs; }

    for g in $GMFP $GMFS; do
        case $g in
            $(CHECK $DCL $ECL $g))
                case $g in
                    $GMFP) ui_print "  Provider: Disabled" ;;
                    $GMFS) ui_print "  Service: Disabled" ;;
                esac
                ;;
            $(CHECK $ECL $HSP $g))
                case $g in
                    $GMFP) ui_print "  Provider: Enabled" ;;
                    $GMFS) ui_print "  Service: Enabled" ;;
                esac
                ;;
        esac
    done
    ui_print ''
}

FIND_GMSF() {
    ui_print '- Finding Fonts Provider '
    local GMSFD=com.google.android.gms/files/fonts

    for d in /data/fonts \
        /data/data/$GMSFD \
        /data/user/*/$GMSFD; do
        [ -d $d ] &&
            ui_print "  Found: $d"
    done
    ui_print '  Done'
    ui_print ''
}

CLEANUP() {
    ui_print '- Cleaning up'
    find $MODPATH/* -maxdepth 0 \
        ! -name module.prop \
        ! -name service.sh \
        ! -name uninstall.sh -exec basename {} \; |
        while IFS= read -r CLEAN; do
            rm -f $MODPATH/$CLEAN
            ui_print "  Removed: $CLEAN"
        done
    ui_print '  Done'
    ui_print ''
}

SET_PERM() {
    ui_print '- Setting permissions'
    find $MODPATH/* -maxdepth 0 \
        -exec basename {} \; |
        while IFS= read -r PERM; do
            set_perm $MODPATH/$PERM 0 0 0777 u:object_r:system_file:s0
            ui_print "  Granted: $PERM"
        done
    ui_print '  Done'
    ui_print ''
}

STATE_GMSF; FIND_GMSF; CLEANUP; SET_PERM


