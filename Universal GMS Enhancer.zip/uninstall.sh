rm -rf /data/adb/UGE
